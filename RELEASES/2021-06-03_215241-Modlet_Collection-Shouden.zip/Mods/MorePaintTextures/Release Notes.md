**MorePaintTextures** Add missing textures to the paint tool.

* 1.0: There are 10 textures that are present in the game but are not available when painting. This mod makes them available	

[Click here for a list of all my mods](https://github.com/Laotseu/7dtdMods/blob/master/README.md)
